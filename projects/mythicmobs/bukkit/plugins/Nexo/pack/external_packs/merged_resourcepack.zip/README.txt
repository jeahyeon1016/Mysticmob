10lv_soward Java Block/Item Resource Pack

이 팩은 BetterModel의 bbmodel item exporter를 사용하지 않습니다.
Blockbench Java Block/Item 1.21.11 형식의 모델을 Minecraft 26.1 네이티브 item model로 변환한 것입니다.

구조:
assets/rpg/models/item/10lv_soward.json
assets/rpg/items/10lv_soward.json
assets/rpg/textures/item/*.png

MythicMobs:
Options:
  ItemModel: rpg:10lv_soward

지급:
 /mm items get Lv10_PracticeSword 1

Blockbench에서 설정된 display(손 위치/GUI 위치) 값도 그대로 포함했습니다.

------------------------------------------------------------
Added: Lv.10 Wood Mace
ItemModel: rpg:lv10_wood_mace

Files:
assets/rpg/items/lv10_wood_mace.json
assets/rpg/models/item/lv10_wood_mace.json
assets/rpg/textures/item/lv10_wood_mace.png

The uploaded Blockbench model used arbitrary 27.5/40 degree rotations.
They were converted to Minecraft 1.21.11+/26.1 XYZ rotation syntax.

------------------------------------------------------------
v2.3
- Replaced rpg:item/10lv_soward model JSON with the newly supplied sword JSON.
- Preserved the existing sword textures in this pack.
- Texture references were remapped to rpg:item/10lv_soward_tex_XX.
- Preserved uploaded display settings and 1.21.11+ arbitrary XYZ rotations.

------------------------------------------------------------
v2.4
- Added Lv.5 Wood Dagger
- ItemModel: rpg:lv5_wood_dagger
- Added model + item definition + texture
- Preserved uploaded display settings
- Preserved ±47.5° Y rotations
- Converted 17.5° legacy Z rotation to modern XYZ rotation

------------------------------------------------------------
v2.5
- Replaced Lv.5 Wood Dagger model with the latest uploaded JSON.
- Preserved latest firstperson_righthand display settings.
- Texture path remapped to rpg:item/lv5_wood_dagger.
- Preserved ±47.5° rotations and converted 17.5° Z rotation to XYZ format.

------------------------------------------------------------
v2.6
- Replaced the existing sword model with the latest uploaded WOOD_SWORD JSON.
- Kept ItemModel id: rpg:10lv_soward
- Kept existing sword textures in the pack.
- Remapped texture references to rpg:item/10lv_soward_tex_XX.
- Preserved the newest Blockbench display settings and arbitrary XYZ rotations.
